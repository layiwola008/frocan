export const grpahCMSImageLoader = ({ src }) => src;
